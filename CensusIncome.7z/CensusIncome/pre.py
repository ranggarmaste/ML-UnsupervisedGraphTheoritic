maxs = [0,0,0,0,0,0]
mins = [10e9, 10e9, 10e9, 10e9, 10e9, 10e9]


with open('CencusIncome.data.txt', 'r') as f:
    for line in f:
        data = line.split(',')
        try:
            p = [int(data[0]), int(data[2]), int(data[4]), int(data[10]), int(data[11]), int(data[12])]
        except:
            print(data)

            
        for i in range(len(p)):
            if maxs[i] < p[i]:
                maxs[i] = p[i]
            if mins[i] > p[i]:
                mins[i] = p[i]

dataset = []
with open('CencusIncome.data.txt', 'r') as f:
    count = 0
    for line in f:        
        data = line.split(',')
        try:
            p = [int(data[0]), int(data[2]), int(data[4]), int(data[10]), int(data[11]), int(data[12])]
            for i in range(len(p)):
                p[i] = p[i] / (maxs[i] - mins[i])
            dataset.append(p)
        except:
            print(data)

import numpy as np
print( len(dataset) )
distance_matrix = np.zeros([len(dataset), len(dataset)])

attr_count = len(dataset[0])

for i in range(len(dataset)):
    for k in range(i, len(dataset), 1):
        sumsqr = 0
        for q in range(attr_count):
            t = dataset[i][q] - dataset[k][q]
            t *= t
            sumsqr += t
            
        distance_matrix[i,k] = sumsqr
